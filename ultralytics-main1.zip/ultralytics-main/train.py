from ultralytics import YOLO

if __name__ == '__main__':

    model = YOLO(r'ltralytics\cfg\models\v8\yolov8.yaml')    # 1	Original
    # yolov8mbgcsa2.yaml   5	Mamba GCSA
    # yolov8gcsamb.yaml    6	Mamba GGCA1
    # yolov8ggca.yaml    2	  GGCA
    # yolov8gcsa.yaml    4	  GCSA

    # 模型训练
    model.train(data=r"data.yaml",  # 训练数据配置文件
                epochs=3, imgsz=640, batch=1, workers=2)
