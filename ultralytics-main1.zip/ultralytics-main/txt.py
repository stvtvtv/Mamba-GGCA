import warnings
import torch
from ultralytics import YOLO
import numpy as np

# 彻底过滤所有警告
warnings.simplefilter("ignore")

# 加载训练好的模型
def load_model(model_path):
    model = YOLO(model_path)  # 直接加载YOLOv10模型
    return model

# 计算模型指标
def evaluate_model(model, data_path):
    # 使用YOLOv10自带的验证功能
    metrics = model.val(data=data_path)
    return metrics, model

# 主函数
def main():
    # 加载模型
    model = load_model(r'C:\Users\yxy\Downloads\yolov10\yolov10-main\runs\detect\train_v10\weights\best.pt')
    
    # 打印模型结构
    print("\nModel Architecture:")
    print(model.model)  # 打印模型结构信息
    
    # 计算指标
    metrics, model = evaluate_model(model, r'C:\Users\yxy\Downloads\yolov10\yolov10-main\lychee-685-seg\data.yaml')
    
    # 计算平均F1分数
    avg_f1 = sum(metrics.box.f1) / len(metrics.box.f1)
    
    # 计算总FPS
    total_fps = 1000 / (metrics.speed['preprocess'] + metrics.speed['inference'] + metrics.speed['postprocess'])
    
    # 打印结果，四舍五入保留四位小数
    print("\nModel Metrics:")
    print(f"Precision: {round(metrics.box.mp, 4)}")  # 平均Precision
    print(f"Recall: {round(metrics.box.mr, 4)}")  # 平均Recall
    print(f"AP50: {round(metrics.box.map50, 4)}")  # AP50
    print(f"mAP50: {round(metrics.box.maps.mean(), 4)}")  # mAP50
    print(f"F1: {round(avg_f1, 4)}")  # 平均F1
    print(f"Parameters: {sum(p.numel() for p in model.model.parameters())}")  # 参数量
    # 使用AP50作为IOU的近似值，因为AP50是在IOU阈值为0.5时计算的
    print(f"IOU: {round(metrics.box.map50, 4)}")  # IOU (使用AP50作为近似)
    print(f"FPS: {round(total_fps, 4)}")  # 总FPS
    print(f"FPS_infer: {round(1000 / metrics.speed['inference'], 4)}")  # 推理FPS

if __name__ == "__main__":
    main()
