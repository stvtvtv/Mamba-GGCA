import warnings
import torch
import os
import cv2
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path
from collections import defaultdict
from ultralytics import YOLO
from tqdm import tqdm
from ultralytics.utils.plotting import Annotator

# 彻底过滤所有警告
warnings.simplefilter("ignore")

# 加载训练好的模型
def load_model(model_path):
    model = YOLO(model_path)  # 直接加载YOLOv10模型
    return model

# 计算模型指标
def evaluate_model(model, data_path):
    # 使用YOLOv10自带的验证功能
    metrics = model.val(data=data_path)
    return metrics, model

# 生成热力图
def generate_heatmap(predictions, class_names, output_dir):
    # 收集所有检测框的中心点
    all_points = []
    class_points = defaultdict(list)
    
    for result in predictions:
        if result.boxes is not None:
            img_width, img_height = result.orig_shape[1], result.orig_shape[0]
            for box in result.boxes:
                cls = int(box.cls.item())
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                # 计算归一化的中心点
                cx = (x1 + x2) / 2 / img_width
                cy = (y1 + y2) / 2 / img_height
                all_points.append((cx, cy))
                class_points[cls].append((cx, cy))
    
    # 创建输出目录
    heatmap_dir = os.path.join(output_dir, "heatmaps")
    os.makedirs(heatmap_dir, exist_ok=True)
    
    # 生成全局热力图
    if all_points:
        x, y = zip(*all_points)
        plt.figure(figsize=(10, 8))
        sns.kdeplot(x=x, y=y, cmap="viridis", fill=True, thresh=0.05, alpha=0.7)
        plt.title('Global Object Distribution Heatmap')
        plt.xlim(0, 1)
        plt.ylim(1, 0)  # 反转Y轴以匹配图像坐标
        plt.axis('off')
        plt.savefig(os.path.join(heatmap_dir, 'global_heatmap.png'), bbox_inches='tight', pad_inches=0)
        plt.close()
    
    # 生成每个类别的热力图
    for cls, points in class_points.items():
        if points:
            x, y = zip(*points)
            plt.figure(figsize=(10, 8))
            sns.kdeplot(x=x, y=y, cmap="Reds", fill=True, thresh=0.05, alpha=0.7)
            plt.title(f'Heatmap for {class_names[cls]} (Class {cls})')
            plt.xlim(0, 1)
            plt.ylim(1, 0)
            plt.axis('off')
            plt.savefig(os.path.join(heatmap_dir, f'class_{cls}_heatmap.png'), bbox_inches='tight', pad_inches=0)
            plt.close()

# 提取每个类别的前10张图像
def extract_top_images(predictions, class_names, output_dir, top_n=10):
    # 按类别收集图像和置信度
    class_images = defaultdict(list)
    
    for result in predictions:
        if result.boxes is not None:
            img = result.orig_img.copy()
            img_path = Path(result.path).name
            
            # 创建带标注的图像
            annotator = Annotator(img)
            for box in result.boxes:
                cls = int(box.cls.item())
                conf = box.conf.item()
                xyxy = box.xyxy[0].tolist()
                label = f"{class_names[cls]} {conf:.2f}"
                annotator.box_label(xyxy, label)
            
            annotated_img = annotator.result()
            img_data = {
                "image": annotated_img,
                "confidence": max([b.conf.item() for b in result.boxes if int(b.cls.item()) == cls], default=0),
                "img_path": img_path
            }
            
            # 按类别记录
            for box in result.boxes:
                cls = int(box.cls.item())
                class_images[cls].append(img_data)
    
    # 创建输出目录
    top_images_dir = os.path.join(output_dir, "top_images")
    os.makedirs(top_images_dir, exist_ok=True)
    
    # 保存每个类别的前top_n张图像
    for cls, images in class_images.items():
        # 按置信度降序排序
        sorted_images = sorted(images, key=lambda x: x["confidence"], reverse=True)[:top_n]
        
        # 创建类别子目录
        cls_dir = os.path.join(top_images_dir, f"class_{cls}_{class_names[cls]}")
        os.makedirs(cls_dir, exist_ok=True)
        
        # 保存图像
        for i, img_data in enumerate(sorted_images):
            img_path = os.path.join(cls_dir, f"top_{i+1}_{img_data['img_path']}")
            cv2.imwrite(img_path, cv2.cvtColor(img_data["image"], cv2.COLOR_RGB2BGR))

# 主函数
def main():
    # 加载模型
    model_path = r"C:\Users\25515\Desktop\模型文件夹\ys.pt"
    model = load_model(model_path)
    
    # 从模型路径提取模型序号
    model_id = os.path.basename(os.path.dirname(os.path.dirname(model_path)))
    output_dir = f"results_{model_id}"
    os.makedirs(output_dir, exist_ok=True)
    
    # 打印模型结构
    print("\nModel Architecture:")
    print(model.model)  # 打印模型结构信息
    
    # 计算指标
    data_path = r'C:\Users\yxy\Downloads\yolov10\yolov10-main\lychee-685-seg\data.yaml'
    metrics, model = evaluate_model(model, data_path)
    
    # 计算平均F1分数
    avg_f1 = sum(metrics.box.f1) / len(metrics.box.f1)
    
    # 计算总FPS
    total_fps = 1000 / (metrics.speed['preprocess'] + metrics.speed['inference'] + metrics.speed['postprocess'])
    
    # 打印结果
    print("\nModel Metrics:")
    print(f"Precision: {round(metrics.box.mp, 4)}")
    print(f"Recall: {round(metrics.box.mr, 4)}")
    print(f"AP50: {round(metrics.box.map50, 4)}")
    print(f"mAP50: {round(metrics.box.maps.mean(), 4)}")
    print(f"F1: {round(avg_f1, 4)}")
    print(f"Parameters: {sum(p.numel() for p in model.model.parameters())}")
    print(f"IOU: {round(metrics.box.map50, 4)}")
    print(f"FPS: {round(total_fps, 4)}")
    print(f"FPS_infer: {round(1000 / metrics.speed['inference'], 4)}")
    
    # 获取验证集路径
    data_config = model.overrides['data']
    val_path = data_config.get('val', '')  # 从数据配置中获取验证集路径
    
    if val_path:
        print(f"\nProcessing validation set: {val_path}")
        
        # 获取类别名称
        class_names = model.names
        
        # 在验证集上运行预测
        predictions = model.predict(val_path, save=False, verbose=False)
        
        # 生成热力图
        print("Generating heatmaps...")
        generate_heatmap(predictions, class_names, output_dir)
        
        # 提取每个类别的前10张图像
        print("Extracting top images per class...")
        extract_top_images(predictions, class_names, output_dir, top_n=10)
        
        print(f"\nAll results saved to: {output_dir}")
        print(f"- Global and per-class heatmaps in: {output_dir}/heatmaps")
        print(f"- Top images per class in: {output_dir}/top_images")
    else:
        print("Validation path not found in data configuration.")

if __name__ == "__main__":
    main()